import logging
from django.views import View
from django.http import HttpResponse,Http404
from django.template import loader
from interface.apps import InterfaceConfig
from interface.Exception.Interface import Interface as ExceptionInterface

class Auth(View):
    def get(self,request,*args,**kwargs):
        template = loader.get_template('theme/default/login.html')

        # raise Http404("Question does not exist")

        context = {
            'store_list': [
                {'name':'Feltros Arte Sirlei','plano':'Pequeno comerciante'},
                {'name':'Bordados Olga','plano':'Pequeno comerciante'}],
        }

        return HttpResponse(template.render(context,request))
