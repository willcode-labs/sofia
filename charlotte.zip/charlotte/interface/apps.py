import logging
from django.apps import AppConfig

class InterfaceConfig(AppConfig):
    name = 'interface'

    def loggerWarning(error) -> None:
        logging_logger = logging.getLogger('charlotte.interface.warning')
        logging_logger.warning('#' * 10 + ' ' + str(error) + ' ' + '#' * 10)

        if error.error_exception:
            ApiConfig.loggerCritical(error.error_exception)

    def loggerCritical(error) -> None:
        logging_logger = logging.getLogger('charlotte.interface.critical')
        logging_logger.critical('#' * 10 + ' ' + str(error) + ' ' + '#' * 10)
