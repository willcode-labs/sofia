from django.urls import path
from django.conf.urls import handler400,handler403,handler404,handler500
from interface.Controller.v1 import Auth as v1ControllerAuth
# app interface route
# login
urlpatterns = [
    path('interface/v1/autenticacao/',v1ControllerAuth.Auth.as_view(),name='interface_v1_auth'),
]
# error handler
# handler400 = 'interface.Controller.v1.HandlerError.bad_request'
# handler403 = 'interface.Controller.v1.HandlerError.permission_denied'
# handler404 = 'interface.Controller.v1.HandlerError.page_not_found'
# handler500 = 'interface.Controller.v1.HandlerError.server_error'
